#include <iostream>
#include "Ipopt_wrapper.h"
#include <cmath>

using Ipopt_Wrapper::Ipopt_Solver;
using Ipopt_Wrapper::Option;
using Ipopt_Wrapper::Ipopt_Status;
using Ipopt_Wrapper::Simple_Opt_Problem;



void test_simple_problem(bool provide_hessian){
    int dim = 2;

    if (provide_hessian){
        auto f_with_hessian = [](std::vector<double> x, std::vector<double> & grad, std::vector<double> & hessian){
            double obj = (x[0] - 1) * (x[0] - 1) + x[1] * x[1];
            grad[0] = 2 * (x[0] - 1);
            grad[1] = 2 * x[1];
            hessian[0] = 2;
            hessian[1] = 0;
            hessian[2] = 0;
            hessian[3] = 2;
            return obj;
        };

        Simple_Opt_Problem problem(f_with_hessian, dim);

        std::vector<double> x_lb({2, -1});
        std::vector<double> x_ub(dim, 10);
        problem.set_x_lb(x_lb);
        problem.set_x_ub(x_ub);

        Option option;
        option.use_hessian = true;
        option.display_level = 3;
        Ipopt_Solver solver(option);

        auto result = solver.optimize(problem, std::vector<double>(0));

        if (result.status == Ipopt_Wrapper::success){
            std::cout << "opt_f = " << result.opt_obj << ", opt_x = ";
            for (int i = 0; i < dim; ++i){
                std::cout << result.opt_x[i] << ", ";
            }
            std::cout << std::endl;
        }

        auto result2 = solver.optimize(problem, std::vector<double>(0));
    }
    else {
        auto f = [](std::vector<double> x, std::vector<double> & grad){
            double obj = (x[0] - 1) * (x[0] - 1) + x[1] * x[1];
            grad[0] = 2 * (x[0] - 1);
            grad[1] = 2 * x[1];
            return obj;
        };

        Simple_Opt_Problem problem(f, dim);

        std::vector<double> x_lb({2, -1});
        std::vector<double> x_ub(dim, 10);
        problem.set_x_lb(x_lb);
        problem.set_x_ub(x_ub);

        Option option;
        option.use_hessian = true;
        option.display_level = 3;
        Ipopt_Solver solver(option);

        auto result = solver.optimize(problem, std::vector<double>(0));

        if (result.status == Ipopt_Wrapper::success){
            std::cout << "opt_f = " << result.opt_obj << ", opt_x = ";
            for (int i = 0; i < dim; ++i){
                std::cout << result.opt_x[i] << ", ";
            }
            std::cout << std::endl;
        }

    }








}


void test_rosenbrock_problem(){
    int dim = 2;

    auto obj_with_grad = [](const std::vector<double> & x, std::vector<double> & grad) {
        double obj = std::pow(1 - x[0], 2) + 100 * std::pow(x[1] - x[0] * x[0], 2);
        if (!grad.empty()){
            grad[0] = 400 * std::pow(x[0], 3) - 400 * x[0] * x[1] + 2 * x[0] - 2;
            grad[1] = 200 * (x[1] - x[0] * x[0]);
        }
        return obj;
    };


    Ipopt_Wrapper::Simple_Opt_Problem problem(obj_with_grad, dim);

    auto solver = Ipopt_Solver(Option());
    Ipopt_Wrapper::Result result = solver.optimize(problem);

    std::cout << "opt_f = " << result.opt_obj << ", opt_x = ";
    for (int i = 0; i < dim; ++i){
        std::cout << result.opt_x[i] << ", ";
    }
    std::cout << std::endl;


}


int main() {
    test_simple_problem(true);
    //test_rosenbrock_problem();
    return 0;
}
